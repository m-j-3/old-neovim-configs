# 🥳 MJVim

built off the starter template for [LazyVim](https://github.com/LazyVim/LazyVim).
