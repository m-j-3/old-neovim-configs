-- Keymaps are automatically loaded on the VeryLazy event
-- Default keymaps that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/keymaps.lua
-- Add any additional keymaps here
function Map(mode, lhs, rhs, opts)
  local options = { noremap = true, silent = true }
  if opts then
    options = vim.tbl_extend("force", options, opts)
  end
  vim.keymap.set(mode, lhs, rhs, options)
end
vim.g.mapleader = " "
Map("n", ":LH", ":LazyHealth<CR>")

--Must-Have Neovim Keymaps https://medium.com/unixification/must-have-neovim-keymaps-51c283394070
--Movement
Map("n", "<C-h>", "<C-w>h")
Map("n", "<C-j>", "<C-w>j")
Map("n", "<C-k>", "<C-w>k")
Map("n", "<C-l>", "<C-w>l")

-- terminal
Map("t", "<C-h>", "<cmd>wincmd h<CR>")
Map("t", "<C-j>", "<cmd>wincmd j<CR>")
Map("t", "<C-k>", "<cmd>wincmd k<CR>")
Map("t", "<C-l>", "<cmd>wincmd l<CR>")

Map("n", "<C-Up>", ":resize -2<CR>")
Map("n", "<C-Down>", ":resize +2<CR>")
Map("n", "<C-Left>", ":vertical resize -2<CR>")
Map("n", "<C-Right>", ":vertical resize +2<CR>")

-- terminal
Map("t", "<C-Up>", "<cmd>resize -2<CR>")
Map("t", "<C-Down>", "<cmd>resize +2<CR>")
Map("t", "<C-Left>", "<cmd>vertical resize -2<CR>")
Map("t", "<C-Right>", "<cmd>vertical resize +2<CR>")

-- Text Editing
vim.keymap.set("v", "J", ":m '>+1<CR>gv=gv")
vim.keymap.set("v", "K", ":m '<-2<CR>gv=gv")
Map("v", "<", "<gv")
Map("v", ">", ">gv")
--Buffers and Tabs
Map("n", "<TAB>", ":bn<CR>")
Map("n", "<S-TAB>", ":bp<CR>")
Map("n", "<leader>bd", ":bd<CR>") -- from Doom Emacs
--Telescope
Map("n", "<leader>ff", "<cmd> Telescope find_files <CR>")
Map("n", "<leader>fa", "<cmd> Telescope find_files follow=true no_ignore=true hidden=true <CR>")
Map("n", "<leader>fe", "<cmd> Telescope file_browser <CR>")
Map("n", "<leader>fw", "<cmd> Telescope live_grep <CR>")
Map("n", "<leader>fb", "<cmd> Telescope buffers <CR>")
Map("n", "<leader>fh", "<cmd> Telescope help_tags <CR>")
Map("n", "<leader>fo", "<cmd> Telescope oldfiles <CR>")
Map("n", "<leader>fc", "<cmd> Telescope colorschemes <CR>")
--LSP
Map("n", "<leader>gd", ":lua vim.lsp.buf.definition()<CR>")
Map("n", "<leader>gi", ":lua vim.lsp.buf.implementation()<CR>")
Map("n", "K", ":lua vim.lsp.buf.hover()<CR>")
Map("n", "<leader>rn", ":lua vim.lsp.buf.rename()<CR>")
Map("n", "<leader>gr", ":lua vim.lsp.buf.references()<CR>")

--other
Map("n", "J", "mzJ`z")
Map("n", "<C-d>", "<C-d>zz")
Map("n", "<C-u>", "<C-u>zz")
Map("n", "n", "nzzzv")
Map("n", "N", "Nzzzv")

--Code Compiling and Running
vim.keymap.set(
  "n",
  "<leader>ccc",
  ":!gcc % -o %<.exe && %<.exe<CR>",
  { noremap = true, silent = true, desc = "Compile and Run C/C++ files" }
)

vim.keymap.set(
  "n",
  "<leader>r<F5>",
  ':!python "C:/alias commands/restartneovim.py" <CR>',
  { noremap = true, silent = true, desc = "Restart nvim, hopefully" }
)
vim.keymap.set(
  "n",
  "<leader>ccs",
  ":!dotnet run<CR>",
  { noremap = true, silent = true, desc = "Compile and run C# project with .NET Core/5/6+" }
)
vim.keymap.set("n", "<leader>cpy", ":!python %<CR>", { noremap = true, silent = true, desc = "Run Python file" })

vim.keymap.set(
  "n",
  "<leader>cjs",
  ":!node %<CR>",
  { noremap = true, silent = true, desc = "Run JavaScript file with Node.js" }
)

vim.keymap.set("n", "<leader>crub", ":!ruby %<CR>", { noremap = true, silent = true, desc = "Run Ruby file" })
vim.keymap.set(
  "n",
  "<leader>cjav",
  ":!javac % && java %<CR>",
  { noremap = true, silent = true, desc = "Compile and run Java file" }
)

vim.keymap.set(
  "n",
  "<leader>crus",
  ":!cargo run<CR>",
  { noremap = true, silent = true, desc = "Compile and run Rust project with Cargo" }
)

vim.keymap.set("n", "<leader>cg", ":!go run %<CR>", { noremap = true, silent = true, desc = "Run Go file" })

vim.keymap.set(
  "n",
  "<leader>cfor",
  ":!gfortran % && ./a.out<CR>",
  { noremap = true, silent = true, desc = "Compile and run Fortran file" }
)

vim.keymap.set(
  "n",
  "<leader>cada",
  ":!gnatmake % && ./`basename % .adb`<CR>",
  { noremap = true, silent = true, desc = "Compile and run Ada file" }
)

vim.keymap.set(
  "n",
  "<leader>ch",
  ":!ghc % && ./`basename % .hs`<CR>",
  { noremap = true, silent = true, desc = "Compile and run Haskell file" }
)

vim.keymap.set(
  "n",
  "<leader>coc",
  ":!clang -framework Cocoa % && ./a.out<CR>",
  { noremap = true, silent = true, desc = "Compile and run Objective-C file" }
)

vim.keymap.set(
  "n",
  "<leader>ck",
  ":!kotlinc-native % -o output && ./output.kexe<CR>",
  { noremap = true, silent = true, desc = "Compile and run Kotlin/Native file" }
)

vim.keymap.set(
  "n",
  "<leader>cpas",
  ":!fpc % && ./`basename % .pas`<CR>",
  { noremap = true, silent = true, desc = "Compile and run Pascal file" }
)

vim.keymap.set(
  "n",
  "<leader>csw",
  ":!swift run<CR>",
  { noremap = true, silent = true, desc = "Compile and run Swift package" }
)

vim.keymap.set("n", "<leader>cphp", ":!php %<CR>", { noremap = true, silent = true, desc = "Run PHP file" })

vim.keymap.set("n", "<leader>cpl", ":!perl %<CR>", { noremap = true, silent = true, desc = "Run Perl file" })

vim.keymap.set("n", "<leader>csh", ":!bash %<CR>", { noremap = true, silent = true, desc = "Run Shell script" })

vim.keymap.set("n", "<leader>clua", ":!lua %<CR>", { noremap = true, silent = true, desc = "Run Lua file" })

vim.keymap.set("n", "<leader>cel", ":!elixir %<CR>", { noremap = true, silent = true, desc = "Run Elixir file" })

vim.keymap.set(
  "n",
  "<leader>cfs",
  ":!dotnet run<CR>",
  { noremap = true, silent = true, desc = "Compile and run F# project with .NET Core/5/6+" }
)

vim.keymap.set(
  "n",
  "<leader>cd",
  ":!dmd % && ./`basename % .d`<CR>",
  { noremap = true, silent = true, desc = "Compile and run D file" }
)

vim.keymap.set(
  "n",
  "<leader>cerl",
  ":!escript %<CR>",
  { noremap = true, silent = true, desc = "Run Erlang file with escript" }
)

vim.keymap.set(
  "n",
  "<leader>ccob",
  ":!cobc -x % && %:r<CR>",
  { noremap = true, silent = true, desc = "Compile and run COBOL file" }
)
